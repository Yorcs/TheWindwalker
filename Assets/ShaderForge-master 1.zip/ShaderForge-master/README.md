hey everyone~

I will occasionally update this repository with fixes and features!
I'll mostly do compatibility updates for future versions of Unity whenever I need it. if you want older versions, consider pulling one of the older branches! I'll try to name branches helpfully. the oldest version of SF you can get is for Unity 5.x

also, please don't pressure me into doing or fixing things because holy heck I was burnt out at the end of Shader Forge's first lifetime 👀 I'm mostly working on this casually, either when I need a fix or a new feature, or when I have time to fix something other people really want to see fixed!

also, if you enjoy or are currently enjoying or finding Shader Forge useful, please consider supporting me, if you're able to!

you can either do a one-time donation on PayPal at https://www.paypal.me/acegikmo ✨

or a monthly donation on Patreon at https://www.patreon.com/acegikmo 💖

support is entirely optional though, I intend to keep this project open and free, but if you do donate, thank you so hecking much!! if you want to reach me, Twitter is the best place https://twitter.com/FreyaHolmer 🐦

~ Freya

-------------------------------


https://tldrlegal.com/license/mit-license

Copyright 2019 Freya Holmér

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
